# Este es un modulo  con funciones de despiden

def despedirse():
	print("Adios, me estoy despidiendo desde la funciona de la modulo despedidas")


class Despedida():
	def __init__(self):
		print("Adios, me estoy despidiendo desde la init de la clase despedidas")
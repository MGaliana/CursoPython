from setuptools import setup

setup(

	name = "paquete",
	version = "0.1",
	description = "Este es un paquete de ejemplo",
	author = "Miguel Galiana",
	author_email = "yo@gmail.com",
	url = "http://yo.es",
	scripts = [],
	packages = ["paquete","paquete.adios","paquete.hola"]
	
)


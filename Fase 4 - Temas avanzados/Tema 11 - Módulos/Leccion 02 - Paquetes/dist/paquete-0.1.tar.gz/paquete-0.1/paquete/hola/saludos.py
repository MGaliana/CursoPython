# Este es un modulo  con funciones de Saludar

def saludar():
	print("hola, te estoy saludando desde una funcion de saludos")


class Saludo():
	def __init__(self):
		print("Hola Estoy saludando desde una clase")